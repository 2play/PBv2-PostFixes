DIR=/usr/lib/linux-u-boot-current-tinkerboard
write_uboot_platform () 
{ 
    dd if=/dev/zero of=$2 bs=1k count=1023 seek=1 status=noxfer > /dev/null 2>&1;
    dd if=$1/u-boot-rockchip-with-spl.bin of=$2 seek=64 conv=notrunc > /dev/null 2>&1
}


